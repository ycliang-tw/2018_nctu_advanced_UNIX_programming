#include <stdio.h>

int me_init() {
	return 0;
}

