#!/bin/sh

echo Command: $0 $*
echo Total $# arguments
echo Total `printenv | wc -l` environment variables
#printenv

